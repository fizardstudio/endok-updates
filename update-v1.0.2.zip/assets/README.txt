Files generated:
- icon.ico            (Windows, multi-size)
- icon.png            (Linux, 512x512)
- macos/Icon.iconset/ (macOS, PNG set)

On macOS, convert the iconset to ICNS:
    iconutil -c icns Icon.iconset -o icon.icns

Then use:
  - Windows:  assets/icon.ico
  - macOS:    assets/macos/icon.icns   (after running iconutil)
  - Linux:    assets/icon.png
