// File: app/register-preload.js
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('secureBridge', {
    getHwid: () => ipcRenderer.invoke('register-get-hwid'),
    registerDevice: (name, seksi, tipe) => ipcRenderer.invoke('register-submit', { name, seksi, tipe }),
    checkStatus: () => ipcRenderer.invoke('register-check-status'),
    closeApp: () => ipcRenderer.send('register-close-app')
});
