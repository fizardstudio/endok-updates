// File: app/tab-preload.js
// Context: Preload script for BrowserViews to inject an AJAX/fetch network interceptor.

const { webFrame, ipcRenderer } = require('electron');

try {
    // Isolated mouse wheel zoom interceptor
    window.addEventListener('wheel', (e) => {
        if (e.ctrlKey) {
            e.preventDefault();
            if (e.deltaY < 0) {
                ipcRenderer.send('zoom-in');
            } else if (e.deltaY > 0) {
                ipcRenderer.send('zoom-out');
            }
        }
    }, { passive: false });

    // Listen for isolated zoom factor commands from the main process
    ipcRenderer.on('set-tab-zoom', (event, factor) => {
        try {
            webFrame.setZoomFactor(factor);
        } catch (err) {}
    });

    // Query and apply initial/saved zoom factor on startup
    ipcRenderer.invoke('get-tab-zoom').then(factor => {
        if (factor) webFrame.setZoomFactor(factor);
    }).catch(() => {});
} catch (e) {
    console.error('[Aterra Zoom Interceptor Error]', e);
}

try {
    webFrame.executeJavaScript(`
        (function() {
            if (window.__diHooked) return;
            window.__diHooked = true;
            window.__latestDIList = [];

            console.log('[Aterra Hook] Network interceptor initialized.');

            // Hook XMLHttpRequest
            const oldOpen = XMLHttpRequest.prototype.open;
            const oldSend = XMLHttpRequest.prototype.send;

            XMLHttpRequest.prototype.open = function(method, url) {
                this._url = url;
                return oldOpen.apply(this, arguments);
            };

            XMLHttpRequest.prototype.send = function() {
                this.addEventListener('load', function() {
                    try {
                        if (this.responseText) {
                            const data = JSON.parse(this.responseText);
                            processData(data);
                        }
                    } catch (e) {}
                });
                return oldSend.apply(this, arguments);
            };

            // Hook fetch
            if (window.fetch) {
                const oldFetch = window.fetch;
                window.fetch = async function() {
                    const response = await oldFetch.apply(this, arguments);
                    try {
                        const clone = response.clone();
                        const data = await clone.json();
                        processData(data);
                    } catch (e) {}
                    return response;
                };
            }

            function processData(data) {
                const findArrays = (obj) => {
                    if (!obj) return;
                    if (Array.isArray(obj)) {
                        if (obj.length > 0) {
                            const first = obj[0];
                            if (first && (first.DaftarIsianId || first.daftarIsianId)) {
                                window.__latestDIList = obj;
                                console.log('[Aterra Hook] Captured DI List:', obj);
                            }
                        }
                        for (const item of obj) {
                            findArrays(item);
                        }
                    } else if (typeof obj === 'object') {
                        for (const key in obj) {
                            findArrays(obj[key]);
                        }
                    }
                };
                findArrays(data);
            }
        })();
    `);
} catch (e) {
    console.error('[Aterra Hook Error]', e);
}

try {
    window.addEventListener('DOMContentLoaded', () => {
        const enableSpellcheck = (el) => {
            if (el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA')) {
                el.setAttribute('spellcheck', 'true');
            }
        };
        
        // Scan initial elements
        document.querySelectorAll('input, textarea').forEach(enableSpellcheck);
        
        // Watch for dynamically added elements
        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                mutation.addedNodes.forEach((node) => {
                    if (node.nodeType === Node.ELEMENT_NODE) {
                        if (node.tagName === 'INPUT' || node.tagName === 'TEXTAREA') {
                            enableSpellcheck(node);
                        }
                        node.querySelectorAll('input, textarea').forEach(enableSpellcheck);
                    }
                });
            });
        });
        observer.observe(document.body, { childList: true, subtree: true });
    });
} catch (e) {
    console.error('[Aterra Spellcheck Activator Error]', e);
}

