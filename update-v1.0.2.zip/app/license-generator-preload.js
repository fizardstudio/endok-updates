// File: app/license-generator-preload.js
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('licenseGen', {
    getHwid: () => ipcRenderer.invoke('license-gen:get-hwid'),
    generateLicense: (hwid) => ipcRenderer.invoke('license-gen:generate', hwid),
    saveLicenseKey: (content) => ipcRenderer.invoke('license-gen:save', content),
    copyToClipboard: (text) => ipcRenderer.send('license-gen:copy', text)
});
