// File: app/about-preload.js
// Context: Preload script for the About window to expose version queries and manual update status listeners.

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('aboutBridge', {
    getAboutVersion: () => ipcRenderer.invoke('get-about-version'),
    checkAboutUpdates: () => ipcRenderer.send('check-about-updates'),
    onUpdateAboutStatus: (fn) => {
        const listener = (event, status) => fn(status);
        ipcRenderer.on('update-about-status', listener);
        return () => {
            ipcRenderer.removeListener('update-about-status', listener);
        };
    }
});
