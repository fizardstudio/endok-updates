// File: app/preload.js
// Context: Primary preload script for the main application shell to securely expose IPC channels and bind event listeners from the main process.

const { contextBridge, ipcRenderer } = require('electron');

// List of allowed IPC channels that can be subscribed to from the renderer UI
const channels = [
  'new-tab-created', 
  'active-tab-changed', 
  'tab-title-updated', 
  'no-tabs-left',
  'navigate-state',
  'status-error',
  'show-notification',
  'tab-url-updated', // [FITUR BARU] Saluran sinkronisasi URL
  'tab-loading',      // [FITUR BARU] Saluran indikator loading
  'zoom-changed',
  'update-progress',   // [NEW] Channel untuk progress download/ekstraksi update
  'active-profile-changed', // [NEW] Channel untuk pemberitahuan pergantian profil
  'session-kicked'
];

const bus = {};
channels.forEach(ch => { bus[ch] = []; });

// Internal utility function to register listeners from the UI securely
function on(channel, fn) {
  if (bus[channel] && typeof fn === 'function') {
    bus[channel].push(fn);
    return () => { // Unsubscribe callback function
      const i = bus[channel].indexOf(fn);
      if (i > -1) bus[channel].splice(i, 1);
    };
  }
  return () => {};
}

// Register IPC listeners from the main process once to prevent memory leaks
channels.forEach(channel => {
  ipcRenderer.on(channel, (event, ...args) => {
    bus[channel].forEach(fn => fn(...args));
  });
});

// Expose strictly defined functions to the secureBridge namespace in the renderer window
contextBridge.exposeInMainWorld('secureBridge', {
  getStatus: () => ipcRenderer.invoke('get-status'),
  openApp:   () => ipcRenderer.invoke('open-app'),
  getNavigateState: () => ipcRenderer.invoke('get-navigate-state'),
  getIpInfo: () => ipcRenderer.invoke('get-ip-info'),
  
  createNewTab: () => ipcRenderer.send('create-new-tab'),
  switchToTab:  (tabId) => ipcRenderer.send('switch-to-tab', tabId),
  closeTab:     (tabId) => ipcRenderer.send('close-tab', tabId),
  refresh:      () => ipcRenderer.send('refresh-active-tab'),
  goBack:       () => ipcRenderer.send('go-back'),
  goForward:    () => ipcRenderer.send('go-forward'),
  openExternal: (url) => ipcRenderer.send('open-external', url),

  onNewTabCreated:    (fn) => on('new-tab-created', fn),
  onActiveTabChanged: (fn) => on('active-tab-changed', fn),
  onTabTitleUpdated:  (fn) => on('tab-title-updated', fn),
  onNoTabsLeft:       (fn) => on('no-tabs-left', fn),
  onNavigateState:    (fn) => on('navigate-state', fn),
  onError:            (fn) => on('status-error', fn),
  onShowNotification: (fn) => on('show-notification', fn),
  
  // [FITUR BARU] Listener untuk UI Chrome
  onTabUrlUpdated:    (fn) => on('tab-url-updated', fn),
  onTabLoading:       (fn) => on('tab-loading', fn),
  zoomIn:             () => ipcRenderer.send('zoom-in'),
  zoomOut:            () => ipcRenderer.send('zoom-out'),
  zoomReset:          () => ipcRenderer.send('zoom-reset'),
  onZoomChanged:      (fn) => on('zoom-changed', fn),
  onUpdateProgress:   (fn) => on('update-progress', fn),
  
  // [NEW] Fitur Profile Switcher
  getTemplateData:        () => ipcRenderer.invoke('get-template-data'),
  changeActiveProfile:    (name) => ipcRenderer.send('change-active-profile', name),
  onActiveProfileChanged: (fn) => on('active-profile-changed', fn),
  onSessionKicked:        (fn) => on('session-kicked', fn),

  // [NEW] Frameless Window Controls & Custom Menus
  minimize:               () => ipcRenderer.send('window-minimize'),
  maximize:               () => ipcRenderer.send('window-maximize'),
  closeWindow:            () => ipcRenderer.send('window-close'),
  triggerMenuAction:      (action) => ipcRenderer.send('trigger-menu-action', action),
  clearCacheRefresh:      () => ipcRenderer.send('clear-cache-refresh'),
  logToMain:              (msg) => ipcRenderer.send('log-to-main', msg),
  setMenuOpenState:       (isOpen) => ipcRenderer.send('set-menu-open-state', isOpen)
});

const fs = require('fs');

function getLocalAterraVersion() {
    try {
        const pkg = JSON.parse(fs.readFileSync(path.join(__dirname, '../package.json'), 'utf-8'));
        return pkg.version || '2.0.2';
    } catch (e) {
        return '2.0.2';
    }
}

contextBridge.exposeInMainWorld('appInfo', {
  version: getLocalAterraVersion(),
  isPackaged: ipcRenderer.sendSync('get-is-packaged')
});